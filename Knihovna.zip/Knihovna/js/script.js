/*
$(document).ready(function() {
    var x = 86;

    $('a[href^="#"]').on('click', function(e) {
    e.preventDefault();

    var target = this.hash;
    var $target = $(target);

    $('html, body').stop().animate({
        'scrollTop':  $target.offset().top - x
      }, 900)
    });
}); 


/*** Burger a menu **
var burger = document.querySelector('.burger');
var menu = document.querySelector('.menu');

burger.onclick = () => {
burger.classList.toggle('is-active');
menu.classList.toggle('active');
};

menu.onclick = () => {
  burger.classList.remove('is-active');
  menu.classList.remove('active');
};
*/

/* Menu */
$(document).ready(function() {
  var page = $('.page');
  page.hide();

  var selected = $ ('.menu').find('.selected');

  function showPage (selected) {
      if (selected.length) {
          var id = selected.find('a').attr('href');
          selectedPage = $(id);
      }

      var newPage = selectedPage.length ? selectedPage : page.eq(0);
      page.not(newPage).hide();
   
      newPage.fadeIn();
  }

  showPage(selected);
  $('.menu a').on('click', function(e){
      var li = $(this).parent();

      li.addClass('selected')
          .siblings().removeClass('selected');
        
      showPage(li);
      e.preventDefault();
  });
}); 